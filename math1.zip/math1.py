
pi = 3.14

def luas_persegi(s):
  return s*s

def luas_lingkaran(r):
  return pi*r*r